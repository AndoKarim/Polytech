commande à lancer : 
Aller dans le dossier du parser et faire
ruby parser.rb < ../test.txt >/output.txt 